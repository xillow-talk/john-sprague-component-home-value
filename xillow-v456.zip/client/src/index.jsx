
import App from './components/App.jsx';

window.App = App;
