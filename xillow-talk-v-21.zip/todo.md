refactor styled components into one file
use styled components cdn 
